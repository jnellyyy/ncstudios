# NC Bracket Bumper for Premiere Pro

This is the stripped-back version: just `[ NC ]`.

## Static assets
- `nc-bold-bracket-black-card.png`
- `nc-bold-bracket-cream-card.png`
- `nc-bold-bracket-main-transparent.png`
- `nc-bold-bracket-mark-only-transparent.png`
- `nc-bold-bracket-white-transparent.png`
- `nc-bold-bracket-logo.svg`

## Premiere sequences
Folders are in `premiere_sequences/`.

1. File > Import
2. Open a sequence folder
3. Select only `frame_0001.png`
4. Tick `Image Sequence`
5. Import
6. Interpret as `15 fps`

Use `01_nc_bracket_black_flash_card` as the main bumper.
Use `02_nc_bracket_gold_overlay_flash` above footage.
Use `03_nc_bracket_cream_flash_card` for a lighter editorial flash.
